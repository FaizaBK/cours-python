# Documentation

- [Documentation officielle de python](https://docs.python.org/3.11)
- [PEPS](https://peps.python.org/)
- [realpython](https://realpython.com)
- [learnpython](https://www.learnpython.org/)
- [w3school](https://www.w3schools.com/python/)
- StackOverflow aura aussi beaucoups de réponses à vos questions.
- Il existe encore plein d'autre site que je ne peux pas tout répertorier

## Version

**<span style="color:red">Faite attention à bien prendre la bonne version en haut à gauche du site</span>**

![documentation-python.png](https://repository-images.githubusercontent.com/92097535/23580f00-1808-11ea-8d8a-3a0a5360af0c)
